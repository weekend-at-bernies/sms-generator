#!/bin/sh

autoreconf -i
./configure $@
